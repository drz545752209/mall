create procedure 插入100条数据()
  BEGIN
    #Routine body goes here...
  DECLARE var INT;
  DECLARE productName VARCHAR(16);
  DECLARE storeName VARCHAR(16);
  DECLARE saleVolume BIGINT(16);
  DECLARE img VARCHAR(32);
  DECLARE type VARCHAR(16);
  DECLARE price INT(8);
  DECLARE description VARCHAR(32);
  DECLARE comments VARCHAR(64);
  DECLARE isShow TINYINT(1);
  DECLARE isDel TINYINT(1);
  SET var=100000;
  WHILE var<1000000 DO
  SET productName=CONCAT('product',var);
  SET storeName='因特尔';
  SET saleVolume=0;
  SET img=CONCAT('E:\新建文件夹\pic\\',var,'.img');
  SET type='相机';
  SET price=100+var;
  SET description=CONCAT('好货',var);
  SET comments=CONCAT('垃圾',var);
  SET isShow=0;
  SET isDel=0;
  INSERT INTO product VALUES (DEFAULT,storeName,productName,saleVolume,img,type,price,description,comments,isShow,isDel);
  SET var=var+1;
  END WHILE;
END;

