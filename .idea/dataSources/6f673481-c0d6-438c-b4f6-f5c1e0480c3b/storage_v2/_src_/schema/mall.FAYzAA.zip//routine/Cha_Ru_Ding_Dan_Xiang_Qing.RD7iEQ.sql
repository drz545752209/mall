create procedure 插入订单详情()
  BEGIN
    #Routine body goes here...
  DECLARE var INT;
  DECLARE product_id INT(8);
  DECLARE sum_consume BIGINT(16);
  DECLARE status VARCHAR(8);
  DECLARE count_consume VARCHAR(16);
  SET var=0;
END;

